#pragma once
#include <iostream>
#include <vector>
#include <thread>

template <typename T, int row_len, int col_len>
class Matrix {
private:
    T** matrix;
    int prow_len;
    int pcol_len;
    int thr_count;
    std::vector<std::thread> thrPool;

    bool check_mul_compat(Matrix a, Matrix b) {  //Check if multiplication can be performed
        return (a.pcol_len == b.prow_len) && (a.prow_len == b.pcol_len);
    }
public:
    Matrix(T data[row_len][col_len], int thr_count) {  // Basic constructor
        this->matrix = new T * [row_len];
        for (int i = 0; i < row_len; ++i) {
            this->matrix[i] = new T[col_len];
            for (int j = 0; j < col_len; ++j) {
                this->matrix[i][j] = data[i][j];
            }
        }
        this->pcol_len = col_len;
        this->prow_len = row_len;
        this->thr_count = thr_count;
    }
    // Copy constructor
    Matrix(const Matrix& other) {       //Copy constructor
        this->prow_len = other.prow_len;
        this->pcol_len = other.pcol_len;
        this->thr_count = other.thr_count;

        // Allocation de la m�moire pour la nouvelle matrice
        this->matrix = new T * [prow_len];
        for (int i = 0; i < prow_len; ++i) {
            this->matrix[i] = new T[pcol_len];
            for (int j = 0; j < pcol_len; ++j) {
                this->matrix[i][j] = other.matrix[i][j];
            }
        }
    }

    ~Matrix() {
        for (int i = 0; i < row_len; ++i) {
            delete[] matrix[i];
        }
        delete[] matrix;
    }

    void print() {
        for (int i = 0; i < prow_len; ++i) {
            for (int j = 0; j < pcol_len; ++j) {
                std::cout << matrix[i][j] << " ";
            }
            std::cout << std::endl;
        }
    }

    Matrix Addition(const Matrix& other) {
        if (prow_len != other.prow_len || pcol_len != other.pcol_len) {
            throw std::invalid_argument("Error message...");
        }
        // Cr�e une copie de cette matrice
        Matrix result(*this); 
        for (int i = 0; i < prow_len; ++i) {
            for (int j = 0; j < pcol_len; ++j) {
                result.matrix[i][j] += other.matrix[i][j];
            }
        }
        return result;
    }

    Matrix Multiplication(const Matrix& other) {
        if (prow_len != other.prow_len || pcol_len != other.pcol_len) {
            throw std::invalid_argument("Error message...");
        }
        // Cr�e une copie de cette matrice
        Matrix result(*this);
        for (int i = 0; i < prow_len; ++i) {
            for (int j = 0; j < other.pcol_len; ++j) {
                for (int k = 0; k < pcol_len; ++k) {
                    result.matrix[i][j] += matrix[i][k] * other.matrix[k][j];
                }
            }
        }
        return result;
    }

};