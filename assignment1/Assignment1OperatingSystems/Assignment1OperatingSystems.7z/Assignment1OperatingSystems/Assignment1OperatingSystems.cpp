
#include <iostream>

#include "matrix.h"
using namespace std;


int main()
{
    std::cout << "Contenu de la matrice 'matrix A':" << std::endl;
    double matdata[2][2] = { {7,8},{3,5} };
    Matrix<double, 2, 2> mat(matdata, 1);
    mat.print();

    std::cout << "Contenu de la matrice 'matrix B':" << std::endl;
    double matdata1[2][2] = { {1,2},{3,4} };
    Matrix<double, 2, 2> mat1(matdata1, 1);
    mat1.print();

    std::cout << "Resultat de la matrice 'matrix A + matrix B':" << std::endl;
    // Addition des deux matrices
    Matrix<double, 2, 2> result = mat.Addition(mat1);
    result.print();

    std::cout << "Resultat de la matrice 'matrix A x matrix B':" << std::endl;
    // Multiplication des deux matrices
    Matrix<double, 2, 2> resultM = mat.Multiplication(mat1);
    resultM.print();

    return 0;
}


